package dev.chestfinder;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.Container;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;

/** Reads live stacks every extraction; never generates inventory input. */
public final class SlotOverlay {
    private SlotOverlay() {}
    public static boolean eligible(Slot slot, Container playerInventory) {
        return slot.container != playerInventory && !slot.isFake() && slot.isActive() && slot.hasItem();
    }
    public static void draw(GuiGraphicsExtractor graphics, AbstractContainerMenu menu, int left, int top) {
        IndexEngine engine = ChestFinderClient.engine();
        if (engine == null) return;
        for (Slot slot : menu.slots) {
            if (!engine.matchesSlot(menu, slot)) continue;
            int x = left + slot.x, y = top + slot.y;
            int color = 0xFF66CC00;
            // One-pixel rim outside the 16x16 item: icons and count text remain intact.
            graphics.fill(x - 1, y - 1, x + 17, y, color);
            graphics.fill(x - 1, y + 16, x + 17, y + 17, color);
            graphics.fill(x - 1, y, x, y + 16, color);
            graphics.fill(x + 16, y, x + 17, y + 16, color);
        }
    }
}
