package dev.chestfinder;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.Window;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

/**
 * Client-only entry point. All input and index work stays on the Minecraft
 * client thread.
 *
 * <p>The mod is passive: it indexes the containers the player opens and never
 * walks, opens, closes, or takes anything by itself.
 */
public final class ChestFinderClient implements ClientModInitializer {
    private static IndexEngine engine;

    public static IndexEngine engine() { return engine; }
    private Hotkey openSearch;
    private Hotkey clear;

    @Override
    public void onInitializeClient() {
        Minecraft minecraft = Minecraft.getInstance();
        engine = new IndexEngine(minecraft);
        ContainerHighlight highlight = new ContainerHighlight(engine);
        KeyMapping.Category category = KeyMapping.Category.register(
            Identifier.fromNamespaceAndPath("chestfinder", "controls"));
        openSearch = register("search", GLFW.GLFW_KEY_G, category);
        clear = register("clear", GLFW.GLFW_KEY_UNKNOWN, category);

        LevelRenderEvents.AFTER_TRANSLUCENT_TERRAIN.register(highlight::render);
        net.fabricmc.fabric.api.event.player.UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (level == minecraft.level && player == minecraft.player) engine.rememberUse(hit.getBlockPos());
            return net.minecraft.world.InteractionResult.PASS;
        });

        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            engine.ensureScope();
            // Poll every tick, even in unrelated screens, so a held key cannot become a
            // new press merely by closing a menu. No hard-coded key state is consulted.
            boolean clearPressed = clear.poll(client);
            boolean searchPressed = openSearch.poll(client);
            boolean inWorld = client.level != null && client.player != null;
            Screen screen = client.gui.screen();
            if (inWorld && client.isWindowActive() && screen == null) {
                if (clearPressed) {
                    engine.clearIndex();
                } else if (searchPressed) {
                    client.gui.setScreen(new SearchScreen(engine));
                }
            }
            // Tick after input so a container opened this tick is seen next tick,
            // by which time the server has had a chance to send its contents.
            engine.tick();
        });
    }

    private static Hotkey register(String name, int defaultKey, KeyMapping.Category category) {
        return new Hotkey(KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.chestfinder." + name, InputConstants.Type.KEYSYM, defaultKey, category)));
    }

    /** Edge-triggered input; supports normal, mouse and unknown/scancode key bindings. */
    private static final class Hotkey {
        private final KeyMapping mapping;
        private boolean held;
        private boolean queued;
        private InputConstants.Key lastBound;

        private Hotkey(KeyMapping mapping) {
            this.mapping = mapping;
            lastBound = KeyMappingHelper.getBoundKeyOf(mapping);
        }

        private boolean poll(Minecraft client) {
            InputConstants.Key bound = KeyMappingHelper.getBoundKeyOf(mapping);
            boolean rebound = !bound.equals(lastBound);
            if (rebound) {
                queued = false;
                lastBound = bound;
            }
            boolean clicked = false;
            while (mapping.consumeClick()) {
                clicked = true;
            }
            if (!client.isWindowActive() || mapping.isUnbound()) {
                held = false;
                queued = false;
                return false;
            }
            boolean down = physicalDown(client.getWindow(), bound);
            // consumeClick also catches an ordinary-world tap shorter than one tick.
            boolean pressed = queued || (!held && (down || clicked));
            queued = false;
            held = down;
            // Rebinding in Controls must not execute that binding on the same tick.
            return !rebound && pressed;
        }

        private boolean physicalDown(Window window, InputConstants.Key bound) {
            return switch (bound.getType()) {
                case KEYSYM -> bound.getValue() >= 0 && InputConstants.isKeyDown(window, bound.getValue());
                case MOUSE -> bound.getValue() >= 0 && bound.getValue() <= GLFW.GLFW_MOUSE_BUTTON_LAST
                    && GLFW.glfwGetMouseButton(window.handle(), bound.getValue()) == GLFW.GLFW_PRESS;
                // GLFW cannot directly poll an unknown physical scan code; fall back
                // to the mapping's own state, which vanilla keeps up to date in-world.
                case SCANCODE -> mapping.isDown();
            };
        }
    }
}
