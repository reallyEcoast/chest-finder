package dev.chestfinder;

/** Testable lifetime of all world-scoped data; null represents disconnection. */
public final class IndexSession<T> {
    public final ContainerIndex index = new ContainerIndex();
    public final SelectionModel selection = new SelectionModel();
    public final PendingInteraction<T> pending = new PendingInteraction<>();
    private Object level;

    public boolean enter(Object nextLevel) {
        if (level == nextLevel) return false;
        level = nextLevel;
        clearIndex();
        return true;
    }
    public void clearIndex() {
        index.clear();
        selection.clear();
        pending.clear();
    }
}
