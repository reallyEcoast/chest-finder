package dev.chestfinder;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.core.BlockPos;

/** Session-only selections, independent of search text, scrolling and screen lifetime. */
public final class SelectionModel {
    private record Key(BlockPos pos, String id, String name) {}
    private final Set<Key> selected = new LinkedHashSet<>();

    public boolean toggle(BlockPos canonical, String id, String name) {
        Key key = new Key(canonical.immutable(), id, name);
        if (selected.remove(key)) return false;
        selected.add(key);
        return true;
    }
    public boolean contains(BlockPos canonical, String id, String name) {
        return selected.contains(new Key(canonical, id, name));
    }
    public List<BlockPos> positions() {
        return selected.stream().map(Key::pos).distinct().toList();
    }
    public void forget(BlockPos pos) { selected.removeIf(key -> key.pos().equals(pos)); }
    public void clear() { selected.clear(); }
}
