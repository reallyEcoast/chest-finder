package dev.chestfinder;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;

/** The two names every indexed stack is remembered by. */
public final class ItemNames {
    private ItemNames() {
    }

    /** The full registry id, e.g. {@code minecraft:oak_planks}; empty for an empty stack. */
    public static String registryId(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return "";
        Identifier key = BuiltInRegistries.ITEM.getKey(stack.getItem());
        return key == null ? "" : key.toString();
    }

    /**
     * The localized name as shown in a tooltip, including a custom name when the
     * stack has one, so searching for a renamed item works.
     */
    public static String displayName(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return "";
        return stack.getHoverName().getString();
    }
}
