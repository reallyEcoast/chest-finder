package dev.chestfinder;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.ChestType;

/**
 * Turns a clicked block position into the one position that identifies the
 * container as a whole.
 *
 * <p>This exists because of double chests. Both halves of a double chest open
 * the same inventory, so recording them as two positions would list every item
 * inside twice. Opening the left half and opening the right half must therefore
 * collapse to the same key.
 *
 * <p>The choice of half is made from the block coordinates alone - never from
 * where the player happens to be standing - so the same chest always resolves
 * to the same position no matter which half was clicked or which direction it
 * was approached from.
 */
public final class ContainerSite {
    private ContainerSite() {
    }

    /**
     * The other half of a double chest, or null for a single chest and for every
     * non-chest container. Barrels, shulker boxes, furnaces, dispensers and
     * hoppers are never paired.
     */
    public static BlockPos partner(ClientLevel level, BlockPos pos) {
        if (level == null || pos == null) return null;
        BlockState state = level.getBlockState(pos);
        if (!(state.getBlock() instanceof ChestBlock) || !state.hasProperty(ChestBlock.TYPE)) return null;
        if (state.getValue(ChestBlock.TYPE) == ChestType.SINGLE) return null;
        return ChestBlock.getConnectedBlockPos(pos, state).immutable();
    }

    /**
     * The position that identifies the container at {@code pos}: itself for a
     * single container, or the agreed-upon half for a double chest.
     */
    public static BlockPos canonical(ClientLevel level, BlockPos pos) {
        BlockPos partner = partner(level, pos);
        return partner == null ? pos.immutable() : firstOf(pos, partner);
    }

    /** World-space union of both block cells, with a small anti-z-fighting expansion. */
    public static net.minecraft.world.phys.AABB bounds(BlockPos pos, BlockPos partner) {
        net.minecraft.world.phys.AABB box = new net.minecraft.world.phys.AABB(pos);
        return (partner == null ? box : box.minmax(new net.minecraft.world.phys.AABB(partner))).inflate(0.01);
    }

    /**
     * The lower of two positions in a fixed coordinate order. Deterministic and
     * symmetric: {@code firstOf(a, b)} always equals {@code firstOf(b, a)}, which
     * is what makes both halves of a double chest agree on one key.
     */
    public static BlockPos firstOf(BlockPos a, BlockPos b) {
        if (a.getX() != b.getX()) return (a.getX() < b.getX() ? a : b).immutable();
        if (a.getZ() != b.getZ()) return (a.getZ() < b.getZ() ? a : b).immutable();
        if (a.getY() != b.getY()) return (a.getY() < b.getY() ? a : b).immutable();
        return a.immutable();
    }
}
