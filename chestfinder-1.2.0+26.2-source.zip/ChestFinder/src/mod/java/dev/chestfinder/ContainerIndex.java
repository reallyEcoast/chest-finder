package dev.chestfinder;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;

/**
 * What was seen in which container. Built up as the engine visits containers and
 * read back by the search screen. Holds no live container references: every
 * entry is a flat snapshot of (position, kind, item, count) taken at open time.
 *
 * <p>Read-only by design. Nothing here can move, take, or change an item - the
 * index only ever answers "which container held this, and where is it".
 */
public final class ContainerIndex {
    /** One item kind inside one container, with the total count across its slots. */
    public record Entry(BlockPos pos, ContainerKind kind, String itemId, String displayName,
                        ItemStack sample, int count) {
    }

    /** A query result: an entry plus where it is relative to the player. */
    public record Hit(Entry entry, double distance) {
    }

    /** Snapshot of one visited container. The tick stamps how fresh it is. */
    public record Record(BlockPos pos, ContainerKind kind, List<Entry> entries, long visitedAtTick) {
    }

    /**
     * One item kind totalled across every container holding it.
     *
     * @param containers how many distinct containers hold it
     * @param total      the sum of the counts in all of them
     */
    public record Group(String itemId, String displayName, ItemStack sample, int containers, int total) {
    }

    private final Map<BlockPos, Record> records = new LinkedHashMap<>();

    /**
     * Joins an item id and a display name into one map key. NUL cannot occur in
     * either part, so an item named "x" in namespace "a:b" cannot collide with
     * one named "b x" in namespace "a" - which a space separator would allow,
     * since display names contain spaces. Written as an escape rather than a raw
     * byte so the source stays plain ASCII. {@link #summarize} and {@link #group}
     * must use the same separator or they would merge the same item differently.
     */
    private static final String SEPARATOR = "\0";

    /**
     * Stores (or replaces) the snapshot for one container. Re-visiting the same
     * position always overwrites, so a container whose contents changed is not
     * reported twice with stale counts.
     */
    public void put(BlockPos pos, ContainerKind kind, List<Entry> entries, long visitedAtTick) {
        BlockPos key = pos.immutable();
        records.put(key, new Record(key, kind, List.copyOf(entries), visitedAtTick));
    }

    public void forget(BlockPos pos) {
        records.remove(pos.immutable());
    }

    public void clear() {
        records.clear();
    }

    public boolean contains(BlockPos pos) {
        return records.containsKey(pos.immutable());
    }

    public int containerCount() {
        return records.size();
    }

    /** Total distinct item kinds across every indexed container. */
    public int entryCount() {
        int total = 0;
        for (Record record : records.values()) total += record.entries().size();
        return total;
    }

    public List<Record> records() {
        return List.copyOf(records.values());
    }

    /**
     * Every indexed item matching the query, nearest-first within equal match
     * quality. Containers of unselected kinds are skipped.
     *
     * @param kinds which container kinds the user currently wants to see
     * @param from  the player position, used only for distance sorting
     * @param limit the maximum number of hits to return
     */
    public List<Hit> search(String query, Set<ContainerKind> kinds, BlockPos from, int limit) {
        List<Hit> hits = new ArrayList<>();
        for (Record record : records.values()) {
            if (!kinds.contains(record.kind())) continue;
            for (Entry entry : record.entries()) {
                if (!ItemMatcher.matches(query, entry.itemId(), entry.displayName())) continue;
                hits.add(new Hit(entry, Math.sqrt(from.distSqr(record.pos()))));
            }
        }
        hits.sort(Comparator
            .comparingInt((Hit hit) -> ItemMatcher.rank(query, hit.entry().itemId(), hit.entry().displayName()))
            .thenComparingDouble(Hit::distance)
            // Ties would otherwise reorder between frames and make the list flicker.
            .thenComparing(hit -> hit.entry().itemId())
            .thenComparingInt(hit -> hit.entry().pos().hashCode()));
        return hits.size() <= limit ? List.copyOf(hits) : List.copyOf(hits.subList(0, limit));
    }

    /**
     * Merges a container's slots into one entry per item kind. Empty slots are
     * dropped; counts are summed; the first stack of a kind becomes the sample
     * used for the icon and tooltip.
     */
    public static List<Entry> summarize(BlockPos pos, ContainerKind kind, List<ItemStack> slots) {
        Map<String, Entry> merged = new LinkedHashMap<>();
        for (ItemStack stack : slots) {
            if (stack == null || stack.isEmpty()) continue;
            String id = ItemNames.registryId(stack);
            String name = ItemNames.displayName(stack);
            // Key on id AND display name so two differently named stacks of the
            // same item (renamed tools, for instance) stay distinguishable.
            String key = id + SEPARATOR + name;
            Entry existing = merged.get(key);
            if (existing == null) {
                merged.put(key, new Entry(pos.immutable(), kind, id, name, stack.copy(), stack.getCount()));
            } else {
                merged.put(key, new Entry(existing.pos(), kind, id, name, existing.sample(),
                    existing.count() + stack.getCount()));
            }
        }
        return List.copyOf(merged.values());
    }

    /**
     * Totals the given hits by item kind, in the order the items first appear.
     *
     * <p>This is what lets one row say "iron ingot x320 across 4 containers"
     * instead of leaving the player to add up four separate rows. Because each
     * container is indexed under exactly one position - both halves of a double
     * chest collapsing to the same key - a container can contribute to a total
     * only once.
     */
    public static List<Group> group(List<Hit> hits) {
        Map<String, Group> merged = new LinkedHashMap<>();
        Map<String, Set<BlockPos>> seen = new LinkedHashMap<>();
        for (Hit hit : hits) {
            Entry entry = hit.entry();
            String key = entry.itemId() + SEPARATOR + entry.displayName();
            Set<BlockPos> positions = seen.computeIfAbsent(key, ignored -> new LinkedHashSet<>());
            // Guard against the same container being counted twice for one item.
            if (!positions.add(entry.pos())) continue;
            Group existing = merged.get(key);
            if (existing == null) {
                merged.put(key, new Group(entry.itemId(), entry.displayName(), entry.sample(),
                    1, entry.count()));
            } else {
                merged.put(key, new Group(existing.itemId(), existing.displayName(), existing.sample(),
                    existing.containers() + 1, existing.total() + entry.count()));
            }
        }
        return List.copyOf(merged.values());
    }
}
