package dev.chestfinder;

import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;

/**
 * Sanity-checks an open container screen against the block it is believed to
 * belong to.
 *
 * <p>The client is told a menu's type and slot count but not which block opened
 * it. ChestFinder guesses the block from what the player was looking at, and a
 * wrong guess would file a chest's contents under a furnace's coordinates. This
 * class rejects the pairings that cannot be right: a 3-slot furnace menu is
 * never a barrel, a 27-slot chest menu is never a hopper.
 *
 * <p>Pure logic over the menu type and slot count, so it is unit-testable
 * without a running client.
 */
public final class MenuShape {
    /** Slots in a single chest or barrel. */
    public static final int SINGLE_CHEST_SLOTS = 27;
    /** Slots in a double chest - two single chests sharing one inventory. */
    public static final int DOUBLE_CHEST_SLOTS = 54;

    private MenuShape() {
    }

    /**
     * Whether an open menu could plausibly belong to a container of this kind.
     *
     * <p>Unknown menu types are accepted: a modded container that reports a type
     * this mod has never heard of should still be indexable, and the position it
     * is filed under came from the block the player actually looked at.
     */
    public static boolean plausible(AbstractContainerMenu menu, ContainerKind kind) {
        if (menu == null || kind == null) return false;
        MenuType<?> type = menuType(menu);
        if (type == null) return true;
        return switch (kind) {
            // Either half of a double chest opens a 54-slot menu; a single one 27.
            case CHEST, TRAPPED_CHEST -> isChestMenu(type);
            // A barrel is always single, so a 54-slot menu is not a barrel.
            case BARREL -> type == MenuType.GENERIC_9x3;
            case SHULKER_BOX -> type == MenuType.SHULKER_BOX || type == MenuType.GENERIC_9x3;
            case FURNACE -> type == MenuType.FURNACE || type == MenuType.BLAST_FURNACE
                || type == MenuType.SMOKER;
            case DISPENSER -> type == MenuType.GENERIC_3x3;
            case HOPPER -> type == MenuType.HOPPER;
        };
    }

    /** Strict association rejects unknown/custom shapes instead of guessing. */
    public static boolean exact(AbstractContainerMenu menu, ContainerKind kind, int slots) {
        MenuType<?> type = menuType(menu);
        if (type == null || !plausible(menu, kind)) return false;
        if (kind == ContainerKind.CHEST || kind == ContainerKind.TRAPPED_CHEST) {
            return slots == 54 ? type == MenuType.GENERIC_9x6 : type == MenuType.GENERIC_9x3;
        }
        return true;
    }

    /** Whether a menu type is one of the six generic chest sizes. */
    public static boolean isChestMenu(MenuType<?> type) {
        return type == MenuType.GENERIC_9x1 || type == MenuType.GENERIC_9x2
            || type == MenuType.GENERIC_9x3 || type == MenuType.GENERIC_9x4
            || type == MenuType.GENERIC_9x5 || type == MenuType.GENERIC_9x6;
    }

    /**
     * Whether a container slot count means a double chest. Used only for
     * reporting; the index key comes from {@link ContainerSite#canonical}, which
     * does not depend on this.
     */
    public static boolean isDoubleChest(int containerSlotCount) {
        return containerSlotCount >= DOUBLE_CHEST_SLOTS;
    }

    /**
     * A menu's type, or null when the menu refuses to report one. Client-side
     * menus built without a registered type throw rather than return null, so the
     * exception is what "unknown" looks like here.
     */
    private static MenuType<?> menuType(AbstractContainerMenu menu) {
        try {
            return menu.getType();
        } catch (RuntimeException unregistered) {
            return null;
        }
    }
}
