package dev.chestfinder;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

/**
 * Watches the containers the player opens and remembers what was inside.
 *
 * <p>The player does the walking and the opening. This class only looks: every
 * tick it checks whether a container screen is open, works out which block it
 * belongs to, and once the contents have settled it files a snapshot into the
 * {@link ContainerIndex} the search screen reads from.
 *
 * <p><strong>Strictly read-only.</strong> It never clicks a slot, never calls
 * any pick-up / quick-move / drop API, never opens or closes a container, and
 * never touches the player's inventory. It cannot move the player and it cannot
 * move an item. Reading an open screen is the only thing it does.
 *
 * <p>A container's contents are not known to the client until the container is
 * opened - the server does not send them before that. That is why this is the
 * whole mechanism: open a chest once, and it is indexed from then on.
 *
 * <p>All work happens on the client thread from START_CLIENT_TICK.
 */
public final class IndexEngine {
    /** Ticks an open container is observed before its contents are trusted. */
    private static final int READ_SETTLE = 5;
    /** Ticks after filing a snapshot before the same screen may be re-read. */
    private static final int REREAD_INTERVAL = 20;

    private final Minecraft mc;
    private final IndexSession<Interaction> session = new IndexSession<>();
    private final ContainerIndex index = session.index;
    private final Set<ContainerKind> kinds = EnumSet.copyOf(ContainerKind.ALL);
    private final SelectionModel selection = session.selection;
    private record Interaction(BlockPos pos, ContainerKind kind, BlockEntity entity, int slots) {}
    private final PendingInteraction<Interaction> pending = session.pending;
    private BlockEntity watchedEntity;
    private int watchedSlots;

    public SelectionModel selection() { return selection; }

    /** Called before input and by rendering: never retain data across level instances. */
    public void ensureScope() {
        if (!session.enter(mc.level)) return;
        forgetWatched();
        status = "";
    }

    public void clearMarkers() {
        selection.clear();
        setStatus(Component.translatable("chestfinder.message.markers_cleared"));
    }

    public void rememberUse(BlockPos clicked) {
        ensureScope();
        pending.clear();
        if (mc.level == null || mc.player == null || mc.gui.screen() != null
                || mc.player.isSpectator() || mc.player.isShiftKeyDown()
                || !mc.level.hasChunkAt(clicked)) return;
        ContainerKind kind = ContainerKind.of(mc.level.getBlockEntity(clicked));
        if (kind == null) return;
        BlockPos pos = ContainerSite.canonical(mc.level, clicked);
        if (!validSite(pos)) return;
        int slots = expectedSlots(kind, ContainerSite.partner(mc.level, pos) != null);
        pending.record(mc.level, tickCounter,
            new Interaction(pos, kind, mc.level.getBlockEntity(pos), slots));
    }

    private static int expectedSlots(ContainerKind kind, boolean paired) {
        return switch (kind) {
            case CHEST, TRAPPED_CHEST -> paired ? 54 : 27;
            case BARREL, SHULKER_BOX -> 27;
            case FURNACE -> 3;
            case DISPENSER -> 9;
            case HOPPER -> 5;
        };
    }

    public boolean validSite(BlockPos pos) {
        ensureScope();
        if (mc.level == null || !mc.level.hasChunkAt(pos)
                || ContainerKind.of(mc.level.getBlockEntity(pos)) == null) return false;
        BlockPos partner = ContainerSite.partner(mc.level, pos);
        return partner == null || (mc.level.hasChunkAt(partner)
            && mc.level.getBlockState(pos).getBlock() == mc.level.getBlockState(partner).getBlock()
            && pos.equals(ContainerSite.partner(mc.level, partner)));
    }

    public boolean matchesSlot(AbstractContainerMenu menu, Slot slot) {
        ensureScope();
        return mc.player != null && menu == watchedMenu && menu == mc.player.containerMenu
            && watchedPos != null && validSite(watchedPos)
            && mc.level.getBlockEntity(watchedPos) == watchedEntity
            && expectedSlots(watchedKind, ContainerSite.partner(mc.level, watchedPos) != null) == watchedSlots
            && SlotOverlay.eligible(slot, mc.player.getInventory())
            && selection.contains(watchedPos, ItemNames.registryId(slot.getItem()),
                ItemNames.displayName(slot.getItem()));
    }

    /** The menu currently being observed, used to notice when a new one opens. */
    private AbstractContainerMenu watchedMenu;
    /** Where the watched menu's container sits, or null if it could not be placed. */
    private BlockPos watchedPos;
    private ContainerKind watchedKind;
    private int settled;
    private int sinceFiled;
    private boolean filed;
    private long tickCounter;
    private String status = "";

    public IndexEngine(Minecraft mc) {
        this.mc = mc;
    }

    public ContainerIndex index() {
        return index;
    }

    /** The container kinds the search screen shows. Callers must not modify it. */
    public Set<ContainerKind> kinds() {
        return java.util.Collections.unmodifiableSet(kinds);
    }

    /** Blocks the search screen currently highlights in the world. */
    public List<BlockPos> highlighted() {
        ensureScope();
        return selection.positions();
    }

    public String status() {
        return status;
    }

    /** Throws away everything indexed so far. */
    public void clearIndex() {
        int containers = index.containerCount();
        session.clearIndex();
        forgetWatched();
        Component cleared = Component.translatable("chestfinder.message.cleared", containers);
        setStatus(cleared);
        chat(cleared);
    }

    /** Throws away one container's snapshot, by its canonical position. */
    public void forget(BlockPos pos) {
        if (!index.contains(pos)) return;
        index.forget(pos);
        selection.forget(pos);
        // The watched menu may be the one just dropped; let it be re-filed.
        if (pos.equals(watchedPos)) filed = false;
        setStatus(Component.translatable("chestfinder.message.forgotten", pos.toShortString()));
    }

    public void tick() {
        tickCounter++;
        try {
            tickGuarded();
        } catch (Exception failure) {
            System.Logger logger = System.getLogger(IndexEngine.class.getName());
            logger.log(System.Logger.Level.WARNING, "ChestFinder could not read a container", failure);
            forgetWatched();
        }
    }

    private void tickGuarded() {
        ensureScope();
        LocalPlayer player = mc.player;
        ClientLevel level = mc.level;
        if (player == null || level == null) {
            forgetWatched();
            pending.clear();
            return;
        }

        if (!(mc.gui.screen() instanceof AbstractContainerScreen<?> screen)) {
            if (mc.gui.screen() != null) pending.clear();
            forgetWatched();
            return;
        }
        AbstractContainerMenu menu = screen.getMenu();
        if (menu != player.containerMenu || menu == player.inventoryMenu) {
            // Either a stale screen or the player's own inventory; nothing to index.
            pending.clear();
            forgetWatched();
            return;
        }
        if (menu != watchedMenu) {
            beginWatching(level, menu);
        }
        if (watchedPos == null || watchedKind == null || !kinds.contains(watchedKind)) return;

        if (filed) {
            // Re-read periodically so a container the player is actively editing
            // ends up indexed as it finally stands, not as it was on opening.
            if (++sinceFiled < REREAD_INTERVAL) return;
            sinceFiled = 0;
            file(menu, player);
            return;
        }
        // Let the server's initial slot contents arrive before trusting them.
        if (++settled < READ_SETTLE) return;
        file(menu, player);
    }

    private void beginWatching(ClientLevel level, AbstractContainerMenu menu) {
        watchedMenu = menu;
        settled = 0;
        sinceFiled = 0;
        filed = false;
        watchedPos = null;
        watchedKind = null;
        Interaction used = pending.consume(level, tickCounter);
        if (used == null || !validSite(used.pos())
                || level.getBlockEntity(used.pos()) != used.entity()
                || ContainerKind.of(used.entity()) != used.kind()
                || !MenuShape.plausible(menu, used.kind())
                || !MenuShape.exact(menu, used.kind(), used.slots())
                || menu.slots.size() != used.slots() + 36) return;
        watchedPos = used.pos();
        watchedKind = used.kind();
        watchedEntity = used.entity();
        watchedSlots = used.slots();
    }

    private void file(AbstractContainerMenu menu, LocalPlayer player) {
        if (!validSite(watchedPos) || mc.level.getBlockEntity(watchedPos) != watchedEntity
                || expectedSlots(watchedKind, ContainerSite.partner(mc.level, watchedPos) != null) != watchedSlots) {
            forgetWatched();
            return;
        }
        List<ItemStack> contents = containerSlots(menu, player);
        boolean isNew = !index.contains(watchedPos);
        index.put(watchedPos, watchedKind,
            ContainerIndex.summarize(watchedPos, watchedKind, contents), tickCounter);
        filed = true;
        sinceFiled = 0;
        Component recorded = Component.translatable(
            isNew ? "chestfinder.message.recorded" : "chestfinder.message.updated",
            watchedKind.label(), watchedPos.toShortString(), index.containerCount());
        setStatus(recorded);
        if (isNew) overlay(recorded);
    }

    /**
     * The container's own slots, excluding the player's inventory rows that every
     * container screen also shows. A slot belongs to the container when its
     * backing {@link net.minecraft.world.Container} is not the player inventory.
     */
    private static List<ItemStack> containerSlots(AbstractContainerMenu menu, LocalPlayer player) {
        List<ItemStack> contents = new ArrayList<>();
        for (Slot slot : menu.slots) {
            if (slot.isFake() || !slot.isActive() || slot.container == player.getInventory()) continue;
            contents.add(slot.getItem());
        }
        return contents;
    }

    private void forgetWatched() {
        watchedMenu = null;
        watchedPos = null;
        watchedKind = null;
        settled = 0;
        sinceFiled = 0;
        filed = false;
    }

    private void setStatus(Component text) {
        status = text.getString();
    }

    private void chat(Component text) {
        if (mc.player != null) {
            mc.player.sendSystemMessage(Component.translatable("chestfinder.prefix", text));
        }
    }

    private void overlay(Component text) {
        if (mc.player != null) {
            mc.player.sendOverlayMessage(Component.translatable("chestfinder.prefix", text));
        }
    }
}
