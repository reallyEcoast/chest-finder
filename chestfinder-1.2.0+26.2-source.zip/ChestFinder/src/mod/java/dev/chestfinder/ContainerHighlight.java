package dev.chestfinder;

import com.mojang.blaze3d.vertex.PoseStack;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderContext;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Draws a wireframe box around each container the engine or the search list is
 * pointing at, so the player can see where to walk. Purely visual: it reads
 * engine state and never changes it.
 */
public final class ContainerHighlight {
    private static final int COLOR = 0xFF66CC00;
    private static final float LINE_WIDTH = 2.0f;

    private final IndexEngine engine;

    public ContainerHighlight(IndexEngine engine) {
        this.engine = engine;
    }

    public void render(LevelRenderContext context) {
        List<BlockPos> containers = engine.highlighted();
        if (containers.isEmpty()) {
            return;
        }
        Vec3 camera = context.levelState().cameraRenderState.pos;
        PoseStack poseStack = context.poseStack();
        for (BlockPos pos : containers) {
            if (!engine.validSite(pos)) continue;
            var level = net.minecraft.client.Minecraft.getInstance().level;
            VoxelShape shape = Shapes.create(ContainerSite.bounds(pos, ContainerSite.partner(level, pos))
                .move(-pos.getX(), -pos.getY(), -pos.getZ()));
            poseStack.pushPose();
            // Block coordinates are world-absolute; the render pass is camera-relative.
            poseStack.translate(pos.getX() - camera.x, pos.getY() - camera.y, pos.getZ() - camera.z);
            context.submitNodeCollector()
                    .submitShapeOutline(poseStack, shape, RenderTypes.lines(), COLOR, LINE_WIDTH, false);
            poseStack.popPose();
        }
    }
}
