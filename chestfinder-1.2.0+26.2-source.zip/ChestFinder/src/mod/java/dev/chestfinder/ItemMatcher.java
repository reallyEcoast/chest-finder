package dev.chestfinder;

import java.util.Locale;

/**
 * Decides whether a typed query matches an item. Pure string logic with no
 * Minecraft types, so it is fully unit-tested.
 *
 * <p>A query is matched against two names: the registry id (e.g.
 * {@code minecraft:oak_planks}) and the localized display name (e.g.
 * {@code 橡木木板} or {@code Oak Planks}). Typing in either language works.
 */
public final class ItemMatcher {
    private ItemMatcher() {
    }

    /**
     * True when the query is blank (match everything) or appears in either name.
     *
     * @param query       raw text from the search box
     * @param registryId  the full registry id, namespace included
     * @param displayName the localized name shown in a tooltip
     */
    public static boolean matches(String query, String registryId, String displayName) {
        String needle = normalize(query);
        if (needle.isEmpty()) return true;
        String id = normalize(registryId);
        if (id.contains(needle)) return true;
        // Underscores in ids read as spaces to a user typing "oak planks".
        if (id.replace('_', ' ').contains(needle.replace('_', ' '))) return true;
        return normalize(displayName).contains(needle);
    }

    /**
     * Ranks a match so better ones sort first: 0 exact id path, 1 exact display
     * name, 2 id-path prefix, 3 display-name prefix, 4 anything else. Only ever
     * called for strings {@link #matches} already accepted.
     */
    public static int rank(String query, String registryId, String displayName) {
        String needle = normalize(query);
        if (needle.isEmpty()) return 4;
        String path = normalize(stripNamespace(registryId)).replace('_', ' ');
        String name = normalize(displayName);
        String spaced = needle.replace('_', ' ');
        if (path.equals(spaced)) return 0;
        if (name.equals(needle)) return 1;
        if (path.startsWith(spaced)) return 2;
        if (name.startsWith(needle)) return 3;
        return 4;
    }

    /** Everything after the first colon; the whole string when there is none. */
    public static String stripNamespace(String registryId) {
        if (registryId == null) return "";
        int colon = registryId.indexOf(':');
        return colon < 0 ? registryId : registryId.substring(colon + 1);
    }

    /**
     * Lower-cases with {@link Locale#ROOT} and collapses whitespace runs so
     * "  Oak   Planks " and "oak planks" are the same query. ROOT is required:
     * under a Turkish locale "I" would otherwise fold to a dotless i and stop
     * matching ids such as {@code minecraft:iron_ingot}.
     */
    static String normalize(String text) {
        if (text == null) return "";
        String lower = text.toLowerCase(Locale.ROOT).trim();
        StringBuilder result = new StringBuilder(lower.length());
        boolean lastWasSpace = false;
        for (int index = 0; index < lower.length(); index++) {
            char character = lower.charAt(index);
            if (Character.isWhitespace(character)) {
                if (!lastWasSpace) result.append(' ');
                lastWasSpace = true;
            } else {
                result.append(character);
                lastWasSpace = false;
            }
        }
        return result.toString();
    }
}
