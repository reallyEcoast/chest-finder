package dev.chestfinder;

/** One-shot, short-lived association candidate. Level identity, not dimension name, scopes it. */
public final class PendingInteraction<T> {
    public static final long MAX_AGE = 20;
    private Object level;
    private long at;
    private T value;
    public void record(Object level, long tick, T value) {
        this.level = level;
        this.at = tick;
        this.value = value;
    }
    public T consume(Object level, long tick) {
        T result = this.level == level && tick >= at && tick - at <= MAX_AGE ? value : null;
        clear();
        return result;
    }
    public void clear() { level = null; value = null; }
}
