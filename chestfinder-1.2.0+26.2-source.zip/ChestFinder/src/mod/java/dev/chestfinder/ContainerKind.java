package dev.chestfinder;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.DispenserBlockEntity;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.level.block.entity.TrappedChestBlockEntity;

/**
 * The container kinds the user selected, and nothing else. Membership is decided
 * from the block entity class alone, so a modded subclass of a vanilla container
 * is treated like its vanilla parent.
 *
 * <p>Deliberately absent: shulker boxes carried in the player's inventory (not
 * selected), ender chests (per-player contents, not a findable world location),
 * chiseled bookshelves and brewing stands (not selected), and any entity-based
 * container such as a chest minecart.
 */
public enum ContainerKind {
    CHEST("chest"),
    TRAPPED_CHEST("trapped_chest"),
    BARREL("barrel"),
    SHULKER_BOX("shulker_box"),
    FURNACE("furnace"),
    DISPENSER("dispenser"),
    HOPPER("hopper");

    /** Stable order used by the filter row in the search screen. */
    public static final List<ContainerKind> ALL = List.of(values());

    private final String id;

    ContainerKind(String id) {
        this.id = id;
    }

    public String id() {
        return id;
    }

    public String translationKey() {
        return "chestfinder.container." + id;
    }

    public Component label() {
        return Component.translatable(translationKey());
    }

    /**
     * Returns the kind of a block entity, or null when it is not a container the
     * user asked for. Order matters: trapped chests extend {@link ChestBlockEntity}
     * and droppers extend {@link DispenserBlockEntity}, so the subclass is tested
     * first in both pairs.
     */
    public static ContainerKind of(BlockEntity blockEntity) {
        if (blockEntity instanceof TrappedChestBlockEntity) return TRAPPED_CHEST;
        if (blockEntity instanceof ChestBlockEntity) return CHEST;
        if (blockEntity instanceof BarrelBlockEntity) return BARREL;
        if (blockEntity instanceof ShulkerBoxBlockEntity) return SHULKER_BOX;
        if (blockEntity instanceof AbstractFurnaceBlockEntity) return FURNACE;
        // DropperBlockEntity extends DispenserBlockEntity, so both land here.
        if (blockEntity instanceof DispenserBlockEntity) return DISPENSER;
        if (blockEntity instanceof HopperBlockEntity) return HOPPER;
        return null;
    }
}
