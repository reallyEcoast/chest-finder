package dev.chestfinder;

/**
 * Turns a horizontal offset into one of the eight compass directions, as a
 * translation key suffix. Pure arithmetic so it is unit-tested.
 */
public final class Compass {
    /** Offsets smaller than this in both axes mean "you are standing at it". */
    private static final double HERE = 0.75;

    private Compass() {
    }

    /**
     * The direction from the player to a container.
     *
     * @param dx east-positive offset
     * @param dz south-positive offset
     * @return one of {@code here, north, north_east, east, south_east, south,
     *         south_west, west, north_west}
     */
    public static String direction(double dx, double dz) {
        if (Math.abs(dx) < HERE && Math.abs(dz) < HERE) return "here";
        // Eight equal 45-degree sectors, measured clockwise from north.
        double angle = Math.toDegrees(Math.atan2(dx, -dz));
        if (angle < 0) angle += 360.0;
        int sector = (int) Math.floor((angle + 22.5) / 45.0) % 8;
        return switch (sector) {
            case 0 -> "north";
            case 1 -> "north_east";
            case 2 -> "east";
            case 3 -> "south_east";
            case 4 -> "south";
            case 5 -> "south_west";
            case 6 -> "west";
            default -> "north_west";
        };
    }

    public static String translationKey(double dx, double dz) {
        return "chestfinder.direction." + direction(dx, dz);
    }
}
