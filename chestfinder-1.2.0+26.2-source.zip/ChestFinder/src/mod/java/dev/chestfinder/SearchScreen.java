package dev.chestfinder;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

/**
 * The search box. Typing filters the already-built index live.
 *
 * <p>Results are shown twice over: a totals line per item kind ("iron ingot
 * x320 in 4 containers") followed by one row per container holding it, with its
 * coordinates, direction and distance. Clicking a row reports it to chat and
 * outlines it in the world; the player walks over and takes it themselves.
 *
 * <p>Nothing here can take or move an item, and nothing here moves the player.
 */
public final class SearchScreen extends Screen {
    private static final int FIELD_HEIGHT = 20;
    private static final int ROW_HEIGHT = 20;
    private static final int ICON_SIZE = 16;
    private static final int LIST_TOP = 74;
    private static final int BOTTOM_BAR = 56;
    private static final int MAX_RESULTS = 400;
    private static final int PANEL_BACKGROUND = 0x88000000;
    private static final int ROW_HOVER = 0x44FFFFFF;
    private static final int TOTAL_BACKGROUND = 0x33FFE08A;
    private static final int HEADING_COLOR = 0xFFFFFFFF;
    private static final int DETAIL_COLOR = 0xFFBBBBBB;
    private static final int COUNT_COLOR = 0xFFFFE08A;
    private static final int TOTAL_COLOR = 0xFFFFD24A;

    /**
     * One line in the list: either an item's totals line, or one container that
     * holds it. Totals lines are not clickable; container lines are.
     */
    private sealed interface Row {
        record Total(ContainerIndex.Group group) implements Row {
        }

        record Place(ContainerIndex.Hit hit) implements Row {
        }
    }

    private final IndexEngine engine;
    private EditBox search;
    private List<ContainerIndex.Hit> hits = List.of();
    private List<Row> displayed = List.of();
    private String query = "";
    private int scroll;
    private int rows = 1;

    public SearchScreen(IndexEngine engine) {
        super(Component.translatable("chestfinder.screen.title"));
        this.engine = engine;
    }

    @Override
    protected void init() {
        int margin = 14;
        int usableWidth = Math.max(120, width - margin * 2);
        search = new EditBox(font, margin, 44, usableWidth, FIELD_HEIGHT,
            Component.translatable("chestfinder.search.label"));
        search.setMaxLength(128);
        // The same grey in-field hint vanilla uses for its own search fields.
        search.setHint(Component.translatable("chestfinder.search.hint")
            .withStyle(EditBox.SEARCH_HINT_STYLE));
        search.setValue(query);
        search.setResponder(text -> {
            query = text;
            scroll = 0;
            refresh();
        });
        addRenderableWidget(search);
        setInitialFocus(search);

        rows = Math.max(1, (height - LIST_TOP - BOTTOM_BAR) / ROW_HEIGHT);

        int buttonWidth = Math.min(150, Math.max(40, (usableWidth - 12) / 3));
        int buttonY = height - 28;
        addRenderableWidget(Button.builder(Component.translatable("chestfinder.button.clear"),
                button -> {
                    engine.clearIndex();
                    scroll = 0;
                    refresh();
                    rebuildWidgets();
                })
            .bounds(margin, buttonY, buttonWidth, FIELD_HEIGHT)
            .tooltip(Tooltip.create(Component.translatable("chestfinder.button.clear.tooltip")))
            .build());
        addRenderableWidget(Button.builder(Component.translatable("chestfinder.button.clear_markers"),
                button -> engine.clearMarkers())
            .bounds(margin + 2 * (buttonWidth + 6), buttonY, buttonWidth, FIELD_HEIGHT)
            .tooltip(Tooltip.create(Component.translatable("chestfinder.button.clear_markers.tooltip")))
            .build());
        addRenderableWidget(Button.builder(Component.translatable("chestfinder.button.close"),
                button -> onClose())
            .bounds(margin + buttonWidth + 6, buttonY, buttonWidth, FIELD_HEIGHT)
            .build());

        refresh();
    }

    private void refresh() {
        engine.ensureScope();
        if (minecraft == null || minecraft.player == null) {
            hits = List.of();
            displayed = List.of();
            return;
        }
        BlockPos from = minecraft.player.blockPosition();
        hits = engine.index().search(query, engine.kinds(), from, MAX_RESULTS);
        displayed = buildRows(hits);
        scroll = Math.max(0, Math.min(scroll, Math.max(0, displayed.size() - rows)));
    }

    /**
     * Interleaves each item's totals line with the containers holding it,
     * preserving the index's nearest-first ordering within an item.
     */
    private static List<Row> buildRows(List<ContainerIndex.Hit> hits) {
        List<Row> built = new ArrayList<>();
        for (ContainerIndex.Group group : ContainerIndex.group(hits)) {
            built.add(new Row.Total(group));
            for (ContainerIndex.Hit hit : hits) {
                if (!hit.entry().itemId().equals(group.itemId())) continue;
                if (!hit.entry().displayName().equals(group.displayName())) continue;
                built.add(new Row.Place(hit));
            }
        }
        return List.copyOf(built);
    }

    @Override
    public void tick() {
        if (minecraft.level == null || minecraft.player == null) {
            onClose();
            return;
        }
        // Distances change as the player moves, so re-sort every tick.
        refresh();
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double deltaX, double deltaY) {
        if (!displayed.isEmpty()) {
            int maxScroll = Math.max(0, displayed.size() - rows);
            int next = scroll - (int) Math.signum(deltaY);
            scroll = Math.max(0, Math.min(maxScroll, next));
            refresh();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, deltaX, deltaY);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        engine.ensureScope();
        refresh();
        int row = rowAt(event.y());
        if (event.button() == 0 && event.x() >= 14 && event.x() < width - 14
                && minecraft.player != null && row >= 0 && scroll + row < displayed.size()
                && displayed.get(scroll + row) instanceof Row.Place place) {
            ContainerIndex.Hit hit = place.hit();
            // Clicking only reports the location. Nothing is ever taken.
            minecraft.player.sendSystemMessage(Component.translatable("chestfinder.prefix",
                Component.translatable("chestfinder.message.located",
                    hit.entry().sample().getHoverName(),
                    hit.entry().count(),
                    hit.entry().kind().label(),
                    hit.entry().pos().toShortString(),
                    String.format("%.1f", hit.distance()))));
            boolean selected = engine.selection().toggle(hit.entry().pos(), hit.entry().itemId(), hit.entry().displayName());
            minecraft.player.sendSystemMessage(Component.translatable(selected
                ? "chestfinder.message.selected" : "chestfinder.message.deselected", hit.entry().displayName()));
            return true;
        }
        return super.mouseClicked(event, doubleClick);
    }

    private int rowAt(double mouseY) {
        if (mouseY < LIST_TOP) return -1;
        int row = (int) ((mouseY - LIST_TOP) / ROW_HEIGHT);
        return row >= 0 && row < rows ? row : -1;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
        // Screen's extraction wrapper already draws the background before this method.
        super.extractRenderState(graphics, mouseX, mouseY, partialTick);
        graphics.centeredText(font, getTitle(), width / 2, 14, HEADING_COLOR);
        graphics.centeredText(font, font.plainSubstrByWidth(summary(), Math.max(1, width - 24)),
            width / 2, 28, DETAIL_COLOR);

        int margin = 14;
        int listWidth = Math.max(120, width - margin * 2);
        int listHeight = rows * ROW_HEIGHT;
        graphics.fill(margin, LIST_TOP, margin + listWidth, LIST_TOP + listHeight, PANEL_BACKGROUND);

        if (displayed.isEmpty()) {
            graphics.centeredText(font, Component.translatable(engine.index().containerCount() == 0
                    ? "chestfinder.list.empty.index"
                    : "chestfinder.list.empty.query"),
                width / 2, LIST_TOP + listHeight / 2 - 4, DETAIL_COLOR);
            renderFooter(graphics, margin);
            return;
        }

        graphics.enableScissor(margin, LIST_TOP, margin + listWidth, LIST_TOP + listHeight);
        for (int offset = 0; offset < rows && scroll + offset < displayed.size(); offset++) {
            int rowY = LIST_TOP + offset * ROW_HEIGHT;
            boolean hovered = mouseY >= rowY && mouseY < rowY + ROW_HEIGHT
                && mouseX >= margin && mouseX < margin + listWidth;
            switch (displayed.get(scroll + offset)) {
                case Row.Total total ->
                    renderTotal(graphics, total.group(), margin, listWidth, rowY, hovered, mouseX, mouseY);
                case Row.Place place ->
                    renderPlace(graphics, place.hit(), margin, listWidth, rowY, hovered);
            }
        }
        graphics.disableScissor();
        renderFooter(graphics, margin);
    }

    /** An item's totals line: icon, name, grand total, and how many containers. */
    private void renderTotal(GuiGraphicsExtractor graphics, ContainerIndex.Group group,
            int margin, int listWidth, int rowY, boolean hovered, int mouseX, int mouseY) {
        graphics.fill(margin, rowY, margin + listWidth, rowY + ROW_HEIGHT, TOTAL_BACKGROUND);
        int iconX = margin + 3;
        int iconY = rowY + (ROW_HEIGHT - ICON_SIZE) / 2;
        graphics.item(group.sample(), iconX, iconY);
        graphics.itemDecorations(font, group.sample(), iconX, iconY);

        int textX = iconX + ICON_SIZE + 6;
        graphics.text(font, font.plainSubstrByWidth(group.displayName(), Math.max(1, listWidth / 2)),
            textX, rowY + 6, HEADING_COLOR);

        Component totals = Component.translatable("chestfinder.list.total",
            group.total(), group.containers());
        graphics.text(font, totals, margin + listWidth - font.width(totals) - 4, rowY + 6, TOTAL_COLOR);
        if (hovered) {
            graphics.setTooltipForNextFrame(font, group.sample(), mouseX, mouseY);
        }
    }

    /** One container holding the item: count, kind, coordinates, distance, bearing. */
    private void renderPlace(GuiGraphicsExtractor graphics, ContainerIndex.Hit hit,
            int margin, int listWidth, int rowY, boolean hovered) {
        if (hovered) {
            graphics.fill(margin, rowY, margin + listWidth, rowY + ROW_HEIGHT, ROW_HOVER);
        }
        if (engine.selection().contains(hit.entry().pos(), hit.entry().itemId(), hit.entry().displayName())) {
            graphics.fill(margin, rowY, margin + 3, rowY + ROW_HEIGHT, 0xFF66CC00);
            graphics.text(font, "+", margin + 7, rowY + 6, 0xFF66CC00);
        }
        int textX = margin + ICON_SIZE + 12;
        graphics.text(font, Component.translatable("chestfinder.list.count", hit.entry().count()),
            textX, rowY + 6, COUNT_COLOR);

        Component where = Component.translatable("chestfinder.list.where",
            hit.entry().kind().label(),
            hit.entry().pos().toShortString(),
            String.format("%.1f", hit.distance()),
            direction(hit.entry().pos()));
        graphics.text(font, where, margin + listWidth - font.width(where) - 4, rowY + 6, DETAIL_COLOR);
    }

    private void renderFooter(GuiGraphicsExtractor graphics, int margin) {
        int footerY = LIST_TOP + rows * ROW_HEIGHT + 4;
        String engineStatus = engine.status();
        if (!engineStatus.isEmpty()) {
            graphics.text(font, font.plainSubstrByWidth(engineStatus, Math.max(1, width - margin * 2)),
                margin, footerY, DETAIL_COLOR);
        }
        if (displayed.size() > rows) {
            Component paging = Component.translatable("chestfinder.list.paging",
                scroll + 1, Math.min(scroll + rows, displayed.size()), displayed.size());
            graphics.text(font, paging, margin, footerY + 10, DETAIL_COLOR);
        } else if (engine.index().containerCount() == 0) {
            graphics.text(font, Component.translatable("chestfinder.list.hint.open"),
                margin, footerY + 10, DETAIL_COLOR);
        }
    }

    private String summary() {
        return Component.translatable("chestfinder.screen.summary",
            engine.index().containerCount(), engine.index().entryCount(), hits.size()).getString();
    }

    /** A compass word for the horizontal offset from the player to a container. */
    private Component direction(BlockPos pos) {
        if (minecraft.player == null) return Component.empty();
        double dx = pos.getX() + 0.5 - minecraft.player.getX();
        double dz = pos.getZ() + 0.5 - minecraft.player.getZ();
        return Component.translatable(Compass.translationKey(dx, dz));
    }

    @Override
    public void onClose() {
        minecraft.gui.setScreen(null);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
