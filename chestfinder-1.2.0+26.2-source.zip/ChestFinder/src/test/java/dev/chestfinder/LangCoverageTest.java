package dev.chestfinder;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Checks the language files against each other and against the keys the code uses.
 *
 * <p>A missing key shows up in game as the raw {@code chestfinder.…} string rather
 * than an error, so only a test catches it.
 */
class LangCoverageTest {
    private static final Path LANG =
        Path.of("src", "mod", "resources", "assets", "chestfinder", "lang");
    private static final Path SOURCES = Path.of("src", "mod", "java", "dev", "chestfinder");
    private static final Pattern ENTRY =
        Pattern.compile("\"([^\"]+)\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"");
    /** Translation keys as they appear as literals in the mod sources. */
    private static final Pattern USED =
        Pattern.compile("\"((?:key\\.)?chestfinder\\.[A-Za-z0-9_.]+)\"");

    @Test void englishDefinesEveryKeyTheCodeCanShow() throws IOException {
        Set<String> keys = load("en_us").keySet();
        Set<String> missing = new TreeSet<>(usedKeys());
        missing.removeAll(keys);
        assertTrue(missing.isEmpty(), "en_us is missing: " + missing);
    }

    @Test void englishNamesEveryContainerKindAndDirection() throws IOException {
        Set<String> keys = load("en_us").keySet();
        Set<String> missing = new TreeSet<>();
        // These two families are built by string concatenation, so scanning the
        // sources for literals cannot see them.
        for (ContainerKind kind : ContainerKind.ALL) {
            if (!keys.contains(kind.translationKey())) missing.add(kind.translationKey());
        }
        for (String direction : List.of("here", "north", "north_east", "east", "south_east",
                "south", "south_west", "west", "north_west")) {
            String key = "chestfinder.direction." + direction;
            if (!keys.contains(key)) missing.add(key);
        }
        for (String hotkey : List.of("search", "clear")) {
            String key = "key.chestfinder." + hotkey;
            if (!keys.contains(key)) missing.add(key);
        }
        // Vanilla builds the controls heading from the category id.
        if (!keys.contains("key.category.chestfinder.controls")) {
            missing.add("key.category.chestfinder.controls");
        }
        assertTrue(missing.isEmpty(), "en_us is missing: " + missing);
    }

    @Test void englishDefinesNothingUnused() throws IOException {
        Set<String> known = new TreeSet<>(usedKeys());
        for (ContainerKind kind : ContainerKind.ALL) {
            known.add(kind.translationKey());
        }
        for (String direction : List.of("here", "north", "north_east", "east", "south_east",
                "south", "south_west", "west", "north_west")) {
            known.add("chestfinder.direction." + direction);
        }
        for (String hotkey : List.of("search", "clear")) {
            known.add("key.chestfinder." + hotkey);
        }
        known.add("key.category.chestfinder.controls");
        Set<String> dead = new TreeSet<>(load("en_us").keySet());
        dead.removeAll(known);
        assertTrue(dead.isEmpty(), "en_us defines keys nothing uses: " + dead);
    }

    @Test void everyTranslationHasTheSameKeysAsEnglish() throws IOException {
        Map<String, String> english = load("en_us");
        for (String locale : locales()) {
            if (locale.equals("en_us")) continue;
            Map<String, String> other = load(locale);
            Set<String> missing = new TreeSet<>(english.keySet());
            missing.removeAll(other.keySet());
            assertTrue(missing.isEmpty(), locale + " is missing: " + missing);
            Set<String> extra = new TreeSet<>(other.keySet());
            extra.removeAll(english.keySet());
            assertTrue(extra.isEmpty(), locale + " has keys absent from en_us: " + extra);
        }
    }

    @Test void formatArgumentsLineUpAcrossLocales() throws IOException {
        Map<String, String> english = load("en_us");
        for (String locale : locales()) {
            if (locale.equals("en_us")) continue;
            Map<String, String> other = load(locale);
            for (Map.Entry<String, String> entry : english.entrySet()) {
                String translated = other.get(entry.getKey());
                if (translated == null) continue;
                // Counting %s is not enough: Chinese word order sometimes needs
                // %2$s before %1$s. Compare the multiset of argument positions.
                assertEquals(arguments(entry.getValue()), arguments(translated),
                    locale + " changes the format arguments of " + entry.getKey());
            }
        }
    }

    @Test void noValueIsBlank() throws IOException {
        for (String locale : locales()) {
            load(locale).forEach((key, value) ->
                assertFalse(value.isBlank(), locale + " leaves " + key + " blank"));
        }
    }

    @Test void everyChineseVariantIsShipped() throws IOException {
        List<String> shipped = locales();
        // Traditional, Simplified and Hong Kong Cantonese are separate files in
        // vanilla, so shipping only one leaves the other two in English.
        for (String locale : List.of("zh_tw", "zh_cn", "zh_hk")) {
            assertTrue(shipped.contains(locale), locale + ".json is missing");
        }
    }

    @Test void theChineseFilesAreActuallyChinese() throws IOException {
        for (String locale : List.of("zh_tw", "zh_cn", "zh_hk")) {
            Map<String, String> entries = load(locale);
            long translated = entries.values().stream()
                .filter(LangCoverageTest::hasHanCharacter)
                .count();
            // A few values are pure format strings such as "x%s", so demand a
            // large majority rather than every single one.
            assertTrue(translated * 10 >= entries.size() * 9,
                locale + " looks untranslated: only " + translated + " of "
                    + entries.size() + " values contain Chinese characters");
        }
    }

    private static boolean hasHanCharacter(String text) {
        return text.codePoints().anyMatch(code ->
            Character.UnicodeScript.of(code) == Character.UnicodeScript.HAN);
    }

    private static Set<String> usedKeys() throws IOException {
        Set<String> keys = new TreeSet<>();
        try (var files = Files.list(SOURCES)) {
            for (Path file : files.filter(path -> path.toString().endsWith(".java")).toList()) {
                Matcher matcher = USED.matcher(Files.readString(file, StandardCharsets.UTF_8));
                while (matcher.find()) {
                    String key = matcher.group(1);
                    // Concatenation prefixes such as "chestfinder.direction." are
                    // not keys; the families they build are checked separately.
                    if (!key.endsWith(".")) keys.add(key);
                }
            }
        }
        assertFalse(keys.isEmpty(), "found no translation keys in the sources");
        return keys;
    }

    private static List<String> locales() throws IOException {
        try (var files = Files.list(LANG)) {
            return files.map(path -> path.getFileName().toString())
                .filter(name -> name.endsWith(".json"))
                .map(name -> name.substring(0, name.length() - 5))
                .sorted()
                .toList();
        }
    }

    private static Map<String, String> load(String locale) throws IOException {
        String json = Files.readString(LANG.resolve(locale + ".json"), StandardCharsets.UTF_8);
        Map<String, String> entries = new LinkedHashMap<>();
        Matcher matcher = ENTRY.matcher(json);
        while (matcher.find()) {
            assertNull(entries.put(matcher.group(1), matcher.group(2)),
                locale + " defines " + matcher.group(1) + " twice");
        }
        assertFalse(entries.isEmpty(), locale + " parsed as empty");
        return entries;
    }

    /** Positions of the format arguments, e.g. {@code %2$s %1$s} -> [1, 2]. */
    private static List<Integer> arguments(String text) {
        List<Integer> positions = new ArrayList<>();
        int implicit = 0;
        Matcher matcher = Pattern.compile("%(?:(\\d+)\\$)?s").matcher(text);
        while (matcher.find()) {
            positions.add(matcher.group(1) != null
                ? Integer.parseInt(matcher.group(1)) : ++implicit);
        }
        positions.sort(null);
        return positions;
    }
}
