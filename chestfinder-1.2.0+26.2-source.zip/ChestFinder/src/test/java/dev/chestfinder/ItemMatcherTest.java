package dev.chestfinder;

import java.util.Locale;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/** The search box is the whole feature, so its matching rules are pinned here. */
class ItemMatcherTest {
    @Test void blankQueryMatchesEverything() {
        assertTrue(ItemMatcher.matches("", "minecraft:oak_planks", "Oak Planks"));
        assertTrue(ItemMatcher.matches("   ", "minecraft:oak_planks", "Oak Planks"));
        assertTrue(ItemMatcher.matches(null, "minecraft:oak_planks", "Oak Planks"));
    }

    @Test void matchesTheRegistryPath() {
        assertTrue(ItemMatcher.matches("oak_planks", "minecraft:oak_planks", "Oak Planks"));
        assertTrue(ItemMatcher.matches("planks", "minecraft:oak_planks", "Oak Planks"));
        assertTrue(ItemMatcher.matches("minecraft:oak", "minecraft:oak_planks", "Oak Planks"));
    }

    @Test void underscoresAndSpacesAreInterchangeable() {
        assertTrue(ItemMatcher.matches("oak planks", "minecraft:oak_planks", "Oak Planks"));
        assertTrue(ItemMatcher.matches("iron_ingot", "minecraft:iron_ingot", "Iron Ingot"));
        assertTrue(ItemMatcher.matches("iron ingot", "minecraft:iron_ingot", "Iron Ingot"));
    }

    @Test void matchesTheLocalizedName() {
        // A Chinese client sees Chinese names only; typing them must work.
        assertTrue(ItemMatcher.matches("橡木", "minecraft:oak_planks", "橡木木板"));
        assertTrue(ItemMatcher.matches("木板", "minecraft:oak_planks", "橡木木板"));
        assertFalse(ItemMatcher.matches("雲杉", "minecraft:oak_planks", "橡木木板"));
    }

    @Test void matchingIgnoresCaseAndSurroundingSpace() {
        assertTrue(ItemMatcher.matches("  OAK   Planks  ", "minecraft:oak_planks", "Oak Planks"));
        assertTrue(ItemMatcher.matches("IRON", "minecraft:iron_ingot", "Iron Ingot"));
    }

    @Test void nonMatchesAreRejected() {
        assertFalse(ItemMatcher.matches("diamond", "minecraft:oak_planks", "Oak Planks"));
        assertFalse(ItemMatcher.matches("stone", "minecraft:iron_ingot", "Iron Ingot"));
    }

    @Test void renamedItemsStillMatchTheirId() {
        assertTrue(ItemMatcher.matches("diamond_sword", "minecraft:diamond_sword", "Chopper"));
        assertTrue(ItemMatcher.matches("chopper", "minecraft:diamond_sword", "Chopper"));
    }

    @Test void exactIdPathOutranksEverything() {
        assertEquals(0, ItemMatcher.rank("oak_planks", "minecraft:oak_planks", "Oak Planks"));
        assertEquals(0, ItemMatcher.rank("oak planks", "minecraft:oak_planks", "Oak Planks"));
    }

    @Test void prefixesOutrankMidStringMatches() {
        int prefix = ItemMatcher.rank("oak", "minecraft:oak_planks", "Oak Planks");
        int middle = ItemMatcher.rank("planks", "minecraft:oak_planks", "Oak Planks");
        assertTrue(prefix < middle, "a prefix match must sort before a mid-string one");
    }

    @Test void displayNameRanksBelowItsIdEquivalent() {
        // "Iron Ingot" is an exact display name but not an exact id path.
        assertEquals(1, ItemMatcher.rank("iron ingot", "minecraft:iron_bars", "Iron Ingot"));
        assertEquals(0, ItemMatcher.rank("iron ingot", "minecraft:iron_ingot", "Iron Ingot"));
    }

    @Test void blankQueryRanksLast() {
        assertEquals(4, ItemMatcher.rank("", "minecraft:oak_planks", "Oak Planks"));
    }

    @Test void namespaceIsStripped() {
        assertEquals("oak_planks", ItemMatcher.stripNamespace("minecraft:oak_planks"));
        assertEquals("gizmo", ItemMatcher.stripNamespace("othermod:gizmo"));
        assertEquals("bare", ItemMatcher.stripNamespace("bare"));
        assertEquals("", ItemMatcher.stripNamespace(null));
    }

    @Test void normalizationIsLocaleIndependent() {
        Locale original = Locale.getDefault();
        try {
            // Turkish folds "I" to a dotless i, which would break every id with an I.
            Locale.setDefault(Locale.forLanguageTag("tr"));
            assertTrue(ItemMatcher.matches("IRON", "minecraft:iron_ingot", "Iron Ingot"));
            assertEquals("iron ingot", ItemMatcher.normalize("  IRON   INGOT "));
        } finally {
            Locale.setDefault(original);
        }
    }
}
