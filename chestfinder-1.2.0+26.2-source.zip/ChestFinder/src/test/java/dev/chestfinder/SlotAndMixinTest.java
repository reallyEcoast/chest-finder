package dev.chestfinder;

import com.google.gson.JsonParser;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import net.minecraft.SharedConstants;
import net.minecraft.server.Bootstrap;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.tree.ClassNode;
import static org.junit.jupiter.api.Assertions.*;

class SlotAndMixinTest {
    @BeforeAll static void bootstrap() {
        SharedConstants.tryDetectVersion();
        Bootstrap.bootStrap();
    }
    @Test void excludesPlayerFakeInactiveAndEmptyAndTracksLiveStacks() {
        var chest = new SimpleContainer(2);
        var player = new SimpleContainer(36);
        Slot slot = new Slot(chest, 0, 8, 18);
        assertFalse(SlotOverlay.eligible(slot, player));
        chest.setItem(0, new ItemStack(Items.IRON_INGOT));
        assertTrue(SlotOverlay.eligible(slot, player));
        assertFalse(SlotOverlay.eligible(slot, chest));
        assertFalse(SlotOverlay.eligible(new Slot(chest, 0, 0, 0) {
            @Override public boolean isFake() { return true; }
        }, player));
        assertFalse(SlotOverlay.eligible(new Slot(chest, 0, 0, 0) {
            @Override public boolean isActive() { return false; }
        }, player));
        SelectionModel selected = new SelectionModel();
        var pos = net.minecraft.core.BlockPos.ZERO;
        selected.toggle(pos, ItemNames.registryId(slot.getItem()), ItemNames.displayName(slot.getItem()));
        chest.setItem(1, new ItemStack(Items.IRON_INGOT));
        for (int i = 0; i < 2; i++) assertTrue(selected.contains(pos,
            ItemNames.registryId(chest.getItem(i)), ItemNames.displayName(chest.getItem(i))));
        chest.setItem(0, new ItemStack(Items.GOLD_INGOT));
        assertFalse(selected.contains(pos, ItemNames.registryId(slot.getItem()), ItemNames.displayName(slot.getItem())));
        chest.removeItemNoUpdate(0);
        assertFalse(SlotOverlay.eligible(slot, player));
    }
    private AbstractContainerMenu menu(MenuType<?> type) {
        return new AbstractContainerMenu(type, 1) {
            public ItemStack quickMoveStack(Player player, int slot) { return ItemStack.EMPTY; }
            public boolean stillValid(Player player) { return true; }
        };
    }
    @Test void associationRejectsWrongOrUnknownMenuAndWrongChestHalfCount() {
        assertTrue(MenuShape.exact(menu(MenuType.GENERIC_9x3), ContainerKind.CHEST, 27));
        assertTrue(MenuShape.exact(menu(MenuType.GENERIC_9x6), ContainerKind.CHEST, 54));
        assertFalse(MenuShape.exact(menu(MenuType.GENERIC_9x3), ContainerKind.CHEST, 54));
        assertFalse(MenuShape.exact(menu(MenuType.HOPPER), ContainerKind.CHEST, 27));
        assertFalse(MenuShape.exact(menu(null), ContainerKind.CHEST, 27));
    }
    @Test void clientMixinIsRegisteredAndTargetsExact262Descriptor() throws Exception {
        try (var in = getClass().getResourceAsStream("/fabric.mod.json")) {
            var metadata = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
            var entry = metadata.getAsJsonArray("mixins").get(0).getAsJsonObject();
            assertEquals("client", entry.get("environment").getAsString());
            assertEquals("chestfinder.client.mixins.json", entry.get("config").getAsString());
        }
        try (var in = getClass().getResourceAsStream("/chestfinder.client.mixins.json")) {
            var json = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
            assertTrue(json.get("required").getAsBoolean());
            assertEquals("JAVA_25", json.get("compatibilityLevel").getAsString());
            assertEquals(1, json.getAsJsonObject("injectors").get("defaultRequire").getAsInt());
            assertEquals("AbstractContainerScreenMixin", json.getAsJsonArray("client").get(0).getAsString());
            assertEquals("dev.chestfinder.mixin", json.get("package").getAsString());
        }
        ClassNode target = new ClassNode();
        new ClassReader("net.minecraft.client.gui.screens.inventory.AbstractContainerScreen").accept(target, 0);
        String descriptor = "(Lnet/minecraft/client/gui/GuiGraphicsExtractor;IIF)V";
        assertEquals(1, target.methods.stream().filter(m -> m.name.equals("extractContents") && m.desc.equals(descriptor)).count());
        ClassNode mixin = new ClassNode();
        new ClassReader("dev.chestfinder.mixin.AbstractContainerScreenMixin").accept(mixin, 0);
        var inject = mixin.methods.stream().filter(m -> m.name.equals("chestfinder$matchingSlots")).findFirst().orElseThrow();
        var annotation = inject.visibleAnnotations.stream().filter(a -> a.desc.endsWith("/Inject;")).findFirst().orElseThrow();
        assertTrue(annotation.values.toString().contains("extractContents" + descriptor));
        assertTrue(target.fields.stream().anyMatch(f -> f.name.equals("menu") && f.desc.equals("Lnet/minecraft/world/inventory/AbstractContainerMenu;")));
        assertTrue(target.fields.stream().anyMatch(f -> f.name.equals("leftPos") && f.desc.equals("I")));
        assertTrue(target.fields.stream().anyMatch(f -> f.name.equals("topPos") && f.desc.equals("I")));
    }
}
