package dev.chestfinder;

import java.util.List;
import java.util.Set;
import net.minecraft.SharedConstants;
import net.minecraft.core.BlockPos;
import net.minecraft.server.Bootstrap;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * The index is what the search box reads, so its merging and ordering are pinned
 * against the real {@link ItemStack} and registry rather than stand-ins.
 */
class ContainerIndexTest {
    private static final BlockPos ORIGIN = BlockPos.ZERO;

    @BeforeAll static void bootstrap() {
        SharedConstants.tryDetectVersion();
        Bootstrap.bootStrap();
        net.minecraft.core.registries.BuiltInRegistries.DATA_COMPONENT_INITIALIZERS
            .build(net.minecraft.data.registries.VanillaRegistries.createLookup())
            .forEach(net.minecraft.core.component.DataComponentInitializers.PendingComponents::apply);
    }

    @Test void registryIdsComeOutNamespaced() {
        assertEquals("minecraft:iron_ingot", ItemNames.registryId(new ItemStack(Items.IRON_INGOT)));
        assertEquals("", ItemNames.registryId(ItemStack.EMPTY));
        assertEquals("", ItemNames.registryId(null));
    }

    @Test void summarizeSumsSlotsOfTheSameItem() {
        List<ContainerIndex.Entry> entries = ContainerIndex.summarize(ORIGIN, ContainerKind.CHEST,
            List.of(new ItemStack(Items.IRON_INGOT, 64), new ItemStack(Items.IRON_INGOT, 10)));
        assertEquals(1, entries.size());
        assertEquals(74, entries.get(0).count());
        assertEquals("minecraft:iron_ingot", entries.get(0).itemId());
        assertEquals(ContainerKind.CHEST, entries.get(0).kind());
    }

    @Test void summarizeDropsEmptySlots() {
        List<ContainerIndex.Entry> entries = ContainerIndex.summarize(ORIGIN, ContainerKind.BARREL,
            List.of(ItemStack.EMPTY, new ItemStack(Items.DIAMOND, 3), ItemStack.EMPTY));
        assertEquals(1, entries.size());
        assertEquals(3, entries.get(0).count());
    }

    @Test void summarizeKeepsDifferentItemsApart() {
        List<ContainerIndex.Entry> entries = ContainerIndex.summarize(ORIGIN, ContainerKind.CHEST,
            List.of(new ItemStack(Items.DIAMOND, 1), new ItemStack(Items.IRON_INGOT, 1)));
        assertEquals(2, entries.size());
    }

    @Test void summarizeHoldsACopyNotTheLiveStack() {
        ItemStack live = new ItemStack(Items.DIAMOND, 5);
        List<ContainerIndex.Entry> entries =
            ContainerIndex.summarize(ORIGIN, ContainerKind.CHEST, List.of(live));
        // The server overwrites slot stacks in place; a reference would go stale.
        live.setCount(1);
        assertEquals(5, entries.get(0).sample().getCount());
        assertEquals(5, entries.get(0).count());
    }

    @Test void revisitingAContainerReplacesItsSnapshot() {
        ContainerIndex index = new ContainerIndex();
        index.put(ORIGIN, ContainerKind.CHEST, ContainerIndex.summarize(ORIGIN, ContainerKind.CHEST,
            List.of(new ItemStack(Items.DIAMOND, 10))), 1);
        index.put(ORIGIN, ContainerKind.CHEST, ContainerIndex.summarize(ORIGIN, ContainerKind.CHEST,
            List.of(new ItemStack(Items.DIAMOND, 2))), 2);
        assertEquals(1, index.containerCount());
        assertEquals(1, index.entryCount());
        List<ContainerIndex.Hit> hits =
            index.search("diamond", Set.copyOf(ContainerKind.ALL), ORIGIN, 10);
        assertEquals(2, hits.get(0).entry().count(), "the newer snapshot must win");
    }

    @Test void searchSortsNearestFirstWithinEqualMatchQuality() {
        ContainerIndex index = new ContainerIndex();
        BlockPos far = new BlockPos(30, 0, 0);
        BlockPos near = new BlockPos(5, 0, 0);
        index.put(far, ContainerKind.CHEST, ContainerIndex.summarize(far, ContainerKind.CHEST,
            List.of(new ItemStack(Items.DIAMOND, 1))), 1);
        index.put(near, ContainerKind.BARREL, ContainerIndex.summarize(near, ContainerKind.BARREL,
            List.of(new ItemStack(Items.DIAMOND, 1))), 1);
        List<ContainerIndex.Hit> hits =
            index.search("diamond", Set.copyOf(ContainerKind.ALL), ORIGIN, 10);
        assertEquals(2, hits.size());
        assertEquals(near, hits.get(0).entry().pos());
        assertEquals(5.0, hits.get(0).distance(), 0.001);
    }

    @Test void searchSkipsUnselectedContainerKinds() {
        ContainerIndex index = new ContainerIndex();
        index.put(ORIGIN, ContainerKind.HOPPER, ContainerIndex.summarize(ORIGIN, ContainerKind.HOPPER,
            List.of(new ItemStack(Items.DIAMOND, 1))), 1);
        assertTrue(index.search("diamond", Set.of(ContainerKind.CHEST), ORIGIN, 10).isEmpty());
        assertEquals(1, index.search("diamond", Set.of(ContainerKind.HOPPER), ORIGIN, 10).size());
    }

    @Test void searchHonoursTheLimit() {
        ContainerIndex index = new ContainerIndex();
        for (int x = 1; x <= 5; x++) {
            BlockPos pos = new BlockPos(x, 0, 0);
            index.put(pos, ContainerKind.CHEST, ContainerIndex.summarize(pos, ContainerKind.CHEST,
                List.of(new ItemStack(Items.DIAMOND, 1))), 1);
        }
        assertEquals(2, index.search("diamond", Set.copyOf(ContainerKind.ALL), ORIGIN, 2).size());
    }

    @Test void blankQueryListsEverythingIndexed() {
        ContainerIndex index = new ContainerIndex();
        index.put(ORIGIN, ContainerKind.CHEST, ContainerIndex.summarize(ORIGIN, ContainerKind.CHEST,
            List.of(new ItemStack(Items.DIAMOND, 1), new ItemStack(Items.IRON_INGOT, 1))), 1);
        assertEquals(2, index.search("", Set.copyOf(ContainerKind.ALL), ORIGIN, 10).size());
    }

    @Test void clearAndForgetEmptyTheIndex() {
        ContainerIndex index = new ContainerIndex();
        index.put(ORIGIN, ContainerKind.CHEST, List.of(), 1);
        assertTrue(index.contains(ORIGIN));
        index.forget(ORIGIN);
        assertFalse(index.contains(ORIGIN));
        index.put(ORIGIN, ContainerKind.CHEST, List.of(), 1);
        index.clear();
        assertEquals(0, index.containerCount());
    }

    @Test void recordsKeepTheirKindPositionAndFreshnessStamp() {
        ContainerIndex index = new ContainerIndex();
        BlockPos pos = new BlockPos(4, 64, -7);
        index.put(pos, ContainerKind.TRAPPED_CHEST,
            ContainerIndex.summarize(pos, ContainerKind.TRAPPED_CHEST,
                List.of(new ItemStack(Items.DIAMOND, 1))), 123L);
        List<ContainerIndex.Record> records = index.records();
        assertEquals(1, records.size());
        assertEquals(pos, records.get(0).pos());
        assertEquals(ContainerKind.TRAPPED_CHEST, records.get(0).kind());
        assertEquals(123L, records.get(0).visitedAtTick());
        assertEquals(1, records.get(0).entries().size());
    }

    @Test void everyContainerKindHasAnIdAndKey() {
        for (ContainerKind kind : ContainerKind.ALL) {
            assertFalse(kind.id().isBlank());
            assertEquals("chestfinder.container." + kind.id(), kind.translationKey());
        }
        assertEquals(7, ContainerKind.ALL.size());
    }

    @Test void groupTotalsOneItemAcrossSeveralContainers() {
        ContainerIndex index = new ContainerIndex();
        BlockPos first = new BlockPos(2, 64, 0);
        BlockPos second = new BlockPos(9, 64, 0);
        index.put(first, ContainerKind.CHEST, ContainerIndex.summarize(first, ContainerKind.CHEST,
            List.of(new ItemStack(Items.IRON_INGOT, 64))), 1);
        index.put(second, ContainerKind.BARREL, ContainerIndex.summarize(second, ContainerKind.BARREL,
            List.of(new ItemStack(Items.IRON_INGOT, 20))), 1);
        List<ContainerIndex.Group> groups = ContainerIndex.group(
            index.search("iron", Set.copyOf(ContainerKind.ALL), ORIGIN, 10));
        assertEquals(1, groups.size());
        assertEquals(84, groups.get(0).total());
        assertEquals(2, groups.get(0).containers());
        assertEquals("minecraft:iron_ingot", groups.get(0).itemId());
    }

    @Test void groupKeepsDifferentItemsOnSeparateLines() {
        ContainerIndex index = new ContainerIndex();
        index.put(ORIGIN, ContainerKind.CHEST, ContainerIndex.summarize(ORIGIN, ContainerKind.CHEST,
            List.of(new ItemStack(Items.DIAMOND, 1), new ItemStack(Items.IRON_INGOT, 2))), 1);
        List<ContainerIndex.Group> groups = ContainerIndex.group(
            index.search("", Set.copyOf(ContainerKind.ALL), ORIGIN, 10));
        assertEquals(2, groups.size());
        for (ContainerIndex.Group group : groups) {
            assertEquals(1, group.containers());
        }
    }

    @Test void groupCountsOneContainerOnlyOnce() {
        ContainerIndex.Entry entry = new ContainerIndex.Entry(ORIGIN, ContainerKind.CHEST,
            "minecraft:iron_ingot", "Iron Ingot", new ItemStack(Items.IRON_INGOT), 30);
        // Both halves of a double chest resolve to one position, so a repeated
        // entry for the same position must not inflate the total.
        List<ContainerIndex.Group> groups = ContainerIndex.group(List.of(
            new ContainerIndex.Hit(entry, 1.0), new ContainerIndex.Hit(entry, 1.0)));
        assertEquals(1, groups.size());
        assertEquals(30, groups.get(0).total());
        assertEquals(1, groups.get(0).containers());
    }

    @Test void groupIsEmptyForNoHits() {
        assertTrue(ContainerIndex.group(List.of()).isEmpty());
    }
}
