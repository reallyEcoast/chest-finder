package dev.chestfinder;

import net.minecraft.SharedConstants;
import net.minecraft.server.Bootstrap;
import net.minecraft.world.inventory.MenuType;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * The screen the player has open does not say which block opened it, so the
 * engine attributes it to the block they last looked at. These checks pin the
 * sanity filter that stops a chest's contents being filed under a furnace's
 * coordinates when those two guesses disagree.
 */
class MenuShapeTest {
    @BeforeAll static void bootstrap() {
        SharedConstants.tryDetectVersion();
        Bootstrap.bootStrap();
    }

    @Test void chestMenusAreAcceptedForChests() {
        for (ContainerKind kind : new ContainerKind[] {
                ContainerKind.CHEST, ContainerKind.TRAPPED_CHEST}) {
            assertTrue(MenuShape.isChestMenu(MenuType.GENERIC_9x3));
            assertTrue(MenuShape.isChestMenu(MenuType.GENERIC_9x6));
            assertFalse(MenuShape.isChestMenu(MenuType.HOPPER), kind + " should not accept a hopper");
        }
    }

    @Test void everyGenericChestHeightCountsAsAChestMenu() {
        // A double chest is 9x6 and a single one 9x3; mods use the heights between.
        assertTrue(MenuShape.isChestMenu(MenuType.GENERIC_9x1));
        assertTrue(MenuShape.isChestMenu(MenuType.GENERIC_9x2));
        assertTrue(MenuShape.isChestMenu(MenuType.GENERIC_9x4));
        assertTrue(MenuShape.isChestMenu(MenuType.GENERIC_9x5));
        assertFalse(MenuShape.isChestMenu(MenuType.GENERIC_3x3));
        assertFalse(MenuShape.isChestMenu(MenuType.FURNACE));
    }

    @Test void doubleChestIsRecognisedBySlotCount() {
        assertTrue(MenuShape.isDoubleChest(MenuShape.DOUBLE_CHEST_SLOTS));
        assertFalse(MenuShape.isDoubleChest(MenuShape.SINGLE_CHEST_SLOTS));
        assertEquals(27, MenuShape.SINGLE_CHEST_SLOTS);
        assertEquals(54, MenuShape.DOUBLE_CHEST_SLOTS);
    }

    @Test void aNullMenuOrKindIsNeverPlausible() {
        assertFalse(MenuShape.plausible(null, ContainerKind.CHEST));
        assertFalse(MenuShape.plausible(null, null));
    }
}
