package dev.chestfinder;

import java.util.List;
import net.minecraft.core.BlockPos;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SelectionAndSessionTest {
    private final BlockPos a = new BlockPos(1, 64, 2);
    private final BlockPos b = new BlockPos(2, 64, 2);

    @Test void multipleContainersAndItemsToggleIndependently() {
        SelectionModel s = new SelectionModel();
        assertTrue(s.toggle(a, "iron", "Iron"));
        s.toggle(a, "gold", "Gold");
        s.toggle(b, "iron", "Iron");
        assertEquals(List.of(a, b), s.positions());
        assertFalse(s.toggle(a, "iron", "Iron"));
        assertTrue(s.contains(a, "gold", "Gold"));
        assertTrue(s.contains(b, "iron", "Iron"));
        s.forget(a);
        assertEquals(List.of(b), s.positions());
    }
    @Test void renamedItemsAndIdsAreDistinct() {
        SelectionModel s = new SelectionModel();
        s.toggle(a, "iron", "Special");
        assertFalse(s.contains(a, "iron", "Iron"));
        assertFalse(s.contains(a, "gold", "Special"));
        assertTrue(s.contains(a, "iron", "Special"));
    }
    @Test void bothDoubleChestHalvesShareSelectionAndBounds() {
        SelectionModel s = new SelectionModel();
        s.toggle(ContainerSite.firstOf(a, b), "iron", "Iron");
        assertTrue(s.contains(ContainerSite.firstOf(b, a), "iron", "Iron"));
        var box = ContainerSite.bounds(a, b);
        assertEquals(2.02, box.getXsize(), 0.00001);
        assertEquals(1.02, box.getYsize(), 0.00001);
        assertEquals(box, ContainerSite.bounds(b, a));
    }
    @Test void clearMarkersKeepsIndexButClearIndexDropsAllContext() {
        IndexSession<String> s = new IndexSession<>();
        Object level = new Object();
        s.enter(level);
        s.index.put(a, ContainerKind.CHEST, List.of(), 1);
        s.selection.toggle(a, "iron", "Iron");
        s.selection.clear();
        assertEquals(1, s.index.containerCount());
        s.selection.toggle(a, "iron", "Iron");
        s.pending.record(level, 1, "used");
        s.clearIndex();
        assertEquals(0, s.index.containerCount());
        assertTrue(s.selection.positions().isEmpty());
        assertNull(s.pending.consume(level, 2));
    }
    @Test void sameLevelPreservesAndNewLevelOrDisconnectClears() {
        IndexSession<String> s = new IndexSession<>();
        Object level = new Object();
        s.enter(level);
        s.selection.toggle(a, "iron", "Iron");
        s.index.put(a, ContainerKind.CHEST, List.of(), 1);
        s.pending.record(level, 1, "used");
        assertFalse(s.enter(level));
        assertEquals(1, s.selection.positions().size());
        assertTrue(s.enter(new Object()));
        assertEquals(0, s.index.containerCount());
        assertTrue(s.selection.positions().isEmpty());
        assertNull(s.pending.consume(level, 2));
        s.selection.toggle(a, "iron", "Iron");
        assertTrue(s.enter(null));
        assertTrue(s.selection.positions().isEmpty());
    }
    @Test void pendingIsSingleUseAndExpiresAndRequiresSameLevel() {
        PendingInteraction<String> p = new PendingInteraction<>();
        Object level = new Object();
        p.record(level, 100, "a");
        assertEquals("a", p.consume(level, 120));
        assertNull(p.consume(level, 120));
        p.record(level, 100, "b");
        assertNull(p.consume(level, 121));
        p.record(level, 100, "c");
        assertNull(p.consume(new Object(), 101));
        assertNull(p.consume(level, 101));
        p.record(level, 100, "d");
        assertNull(p.consume(level, 99));
    }
}
