package dev.chestfinder;

import net.minecraft.core.BlockPos;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Pins the rule that makes a double chest count once instead of twice.
 *
 * <p>{@link ContainerSite#canonical} needs a live {@code ClientLevel} to read the
 * chest's block state, which cannot exist outside a running client. The part that
 * actually decides the double-chest key is {@link ContainerSite#firstOf}, and that
 * is pure coordinate arithmetic, so it is tested directly here.
 */
class ContainerSiteTest {
    @Test void bothHalvesOfADoubleChestAgreeOnOneKey() {
        BlockPos left = new BlockPos(10, 64, 20);
        BlockPos right = new BlockPos(11, 64, 20);
        // This is the whole fix: whichever half the player clicked, the pair
        // collapses to the same position, so its contents are indexed once.
        assertEquals(ContainerSite.firstOf(left, right), ContainerSite.firstOf(right, left));
    }

    @Test void theChoiceIsSymmetricOnEveryAxis() {
        BlockPos origin = new BlockPos(0, 0, 0);
        for (BlockPos partner : new BlockPos[] {
                new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0),
                new BlockPos(0, 0, 1), new BlockPos(0, 0, -1),
                new BlockPos(0, 1, 0), new BlockPos(0, -1, 0)}) {
            assertEquals(ContainerSite.firstOf(origin, partner),
                ContainerSite.firstOf(partner, origin),
                "asymmetric for partner " + partner);
        }
    }

    @Test void theChoiceIgnoresWhereThePlayerStands() {
        BlockPos west = new BlockPos(-4, 70, 9);
        BlockPos east = new BlockPos(-3, 70, 9);
        BlockPos chosen = ContainerSite.firstOf(west, east);
        // Called many times in any order, as happens when the player walks
        // around the chest and re-opens it, the answer never drifts.
        for (int i = 0; i < 5; i++) {
            assertEquals(chosen, ContainerSite.firstOf(east, west));
            assertEquals(chosen, ContainerSite.firstOf(west, east));
        }
    }

    @Test void theLowerCoordinateWins() {
        assertEquals(new BlockPos(1, 5, 5),
            ContainerSite.firstOf(new BlockPos(2, 5, 5), new BlockPos(1, 5, 5)));
        // X ties break on Z, then on Y.
        assertEquals(new BlockPos(3, 5, 1),
            ContainerSite.firstOf(new BlockPos(3, 5, 2), new BlockPos(3, 5, 1)));
        assertEquals(new BlockPos(3, 4, 7),
            ContainerSite.firstOf(new BlockPos(3, 9, 7), new BlockPos(3, 4, 7)));
    }

    @Test void negativeCoordinatesOrderNumericallyNotByMagnitude() {
        assertEquals(new BlockPos(-9, 0, 0),
            ContainerSite.firstOf(new BlockPos(-9, 0, 0), new BlockPos(2, 0, 0)));
    }

    @Test void thePositionItReturnsIsDetachedFromItsInput() {
        BlockPos.MutableBlockPos moving = new BlockPos(5, 5, 5).mutable();
        BlockPos chosen = ContainerSite.firstOf(moving, new BlockPos(6, 5, 5));
        moving.set(99, 99, 99);
        // An index key that moved with the cursor would corrupt the whole index.
        assertEquals(new BlockPos(5, 5, 5), chosen);
    }

    @Test void identicalPositionsResolveToThemselves() {
        BlockPos pos = new BlockPos(7, 1, 2);
        assertEquals(pos, ContainerSite.firstOf(pos, pos));
    }

    @Test void canonicalAndPartnerTolerateNoLevel() {
        // The engine calls these on a tick where the world may already be gone.
        assertNull(ContainerSite.partner(null, BlockPos.ZERO));
        assertNull(ContainerSite.partner(null, null));
    }
}
