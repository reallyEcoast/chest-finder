package dev.chestfinder;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/** The direction word is the only navigation hint the player gets, so it must be right. */
class CompassTest {
    @Test void negativeZIsNorth() {
        // Minecraft's north is -Z and its east is +X.
        assertEquals("north", Compass.direction(0, -10));
        assertEquals("south", Compass.direction(0, 10));
        assertEquals("east", Compass.direction(10, 0));
        assertEquals("west", Compass.direction(-10, 0));
    }

    @Test void diagonalsNameBothAxes() {
        assertEquals("north_east", Compass.direction(10, -10));
        assertEquals("south_east", Compass.direction(10, 10));
        assertEquals("south_west", Compass.direction(-10, 10));
        assertEquals("north_west", Compass.direction(-10, -10));
    }

    @Test void sectorBoundariesSplitAtTwentyTwoPointFiveDegrees() {
        // 20 degrees east of north is still north; 25 degrees has tipped over.
        assertEquals("north", Compass.direction(Math.tan(Math.toRadians(20)) * 10, -10));
        assertEquals("north_east", Compass.direction(Math.tan(Math.toRadians(25)) * 10, -10));
    }

    @Test void standingOnItReportsHere() {
        assertEquals("here", Compass.direction(0, 0));
        assertEquals("here", Compass.direction(0.5, -0.5));
    }

    @Test void justOutsideTheHereRadiusGetsADirection() {
        assertEquals("south", Compass.direction(0.0, 1.0));
        assertEquals("east", Compass.direction(1.0, 0.0));
    }

    @Test void everyDirectionIsOneOfTheNineKnownWords() {
        for (int degrees = 0; degrees < 360; degrees += 3) {
            double radians = Math.toRadians(degrees);
            // Radius 20 so no sample lands inside the "here" box.
            String direction = Compass.direction(Math.sin(radians) * 20, -Math.cos(radians) * 20);
            assertTrue(java.util.List.of("north", "north_east", "east", "south_east",
                    "south", "south_west", "west", "north_west").contains(direction),
                degrees + " degrees produced " + direction);
        }
    }

    @Test void translationKeyIsNamespaced() {
        assertEquals("chestfinder.direction.north", Compass.translationKey(0, -10));
        assertEquals("chestfinder.direction.here", Compass.translationKey(0, 0));
    }
}
